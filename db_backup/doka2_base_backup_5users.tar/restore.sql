--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.1 (Debian 14.1-1.pgdg110+1)
-- Dumped by pg_dump version 14.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE dota2_base;
--
-- Name: dota2_base; Type: DATABASE; Schema: -; Owner: admin
--

CREATE DATABASE dota2_base WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.utf8';


ALTER DATABASE dota2_base OWNER TO admin;

\connect dota2_base

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: enemies; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.enemies (
    id integer NOT NULL,
    enemy_id character varying(50) NOT NULL,
    fk_enemies_player_match_stat integer,
    winrate_5_match double precision,
    winrate_10_match double precision,
    winrate_20_match double precision,
    winrate_40_match double precision
);


ALTER TABLE public.enemies OWNER TO admin;

--
-- Name: enemies_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.enemies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.enemies_id_seq OWNER TO admin;

--
-- Name: enemies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.enemies_id_seq OWNED BY public.enemies.id;


--
-- Name: player_match_stat; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.player_match_stat (
    id integer NOT NULL,
    match_id character varying(50) NOT NULL,
    match_result character varying(50) NOT NULL,
    teammates_winrate_5_match double precision,
    enemies_winrate_5_match double precision,
    fk_player_match_stat_users integer,
    teammates_winrate_10_match double precision,
    teammates_winrate_20_match double precision,
    teammates_winrate_40_match double precision,
    enemies_winrate_10_match double precision,
    enemies_winrate_20_match double precision,
    enemies_winrate_40_match double precision
);


ALTER TABLE public.player_match_stat OWNER TO admin;

--
-- Name: player_match_stat_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.player_match_stat_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.player_match_stat_id_seq OWNER TO admin;

--
-- Name: player_match_stat_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.player_match_stat_id_seq OWNED BY public.player_match_stat.id;


--
-- Name: teammates; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.teammates (
    id integer NOT NULL,
    teammate_id character varying(50) NOT NULL,
    fk_teammates_player_match_stat integer,
    winrate_5_match double precision,
    winrate_10_match double precision,
    winrate_20_match double precision,
    winrate_40_match double precision
);


ALTER TABLE public.teammates OWNER TO admin;

--
-- Name: teammates_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.teammates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.teammates_id_seq OWNER TO admin;

--
-- Name: teammates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.teammates_id_seq OWNED BY public.teammates.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.users (
    id integer NOT NULL,
    user_id character varying(50) NOT NULL
);


ALTER TABLE public.users OWNER TO admin;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO admin;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: winrate_enemy; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.winrate_enemy (
    id integer NOT NULL,
    win character varying(50) NOT NULL,
    fk_winrate_enemy_player_match_stat integer
);


ALTER TABLE public.winrate_enemy OWNER TO admin;

--
-- Name: winrate_enemy_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.winrate_enemy_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.winrate_enemy_id_seq OWNER TO admin;

--
-- Name: winrate_enemy_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.winrate_enemy_id_seq OWNED BY public.winrate_enemy.id;


--
-- Name: winrate_teammate; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.winrate_teammate (
    id integer NOT NULL,
    win character varying(50) NOT NULL,
    fk_winrate_teammate_player_match_stat integer
);


ALTER TABLE public.winrate_teammate OWNER TO admin;

--
-- Name: winrate_teammate_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.winrate_teammate_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.winrate_teammate_id_seq OWNER TO admin;

--
-- Name: winrate_teammate_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.winrate_teammate_id_seq OWNED BY public.winrate_teammate.id;


--
-- Name: enemies id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.enemies ALTER COLUMN id SET DEFAULT nextval('public.enemies_id_seq'::regclass);


--
-- Name: player_match_stat id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.player_match_stat ALTER COLUMN id SET DEFAULT nextval('public.player_match_stat_id_seq'::regclass);


--
-- Name: teammates id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.teammates ALTER COLUMN id SET DEFAULT nextval('public.teammates_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: winrate_enemy id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.winrate_enemy ALTER COLUMN id SET DEFAULT nextval('public.winrate_enemy_id_seq'::regclass);


--
-- Name: winrate_teammate id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.winrate_teammate ALTER COLUMN id SET DEFAULT nextval('public.winrate_teammate_id_seq'::regclass);


--
-- Data for Name: enemies; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.enemies (id, enemy_id, fk_enemies_player_match_stat, winrate_5_match, winrate_10_match, winrate_20_match, winrate_40_match) FROM stdin;
\.
COPY public.enemies (id, enemy_id, fk_enemies_player_match_stat, winrate_5_match, winrate_10_match, winrate_20_match, winrate_40_match) FROM '$$PATH$$/3361.dat';

--
-- Data for Name: player_match_stat; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.player_match_stat (id, match_id, match_result, teammates_winrate_5_match, enemies_winrate_5_match, fk_player_match_stat_users, teammates_winrate_10_match, teammates_winrate_20_match, teammates_winrate_40_match, enemies_winrate_10_match, enemies_winrate_20_match, enemies_winrate_40_match) FROM stdin;
\.
COPY public.player_match_stat (id, match_id, match_result, teammates_winrate_5_match, enemies_winrate_5_match, fk_player_match_stat_users, teammates_winrate_10_match, teammates_winrate_20_match, teammates_winrate_40_match, enemies_winrate_10_match, enemies_winrate_20_match, enemies_winrate_40_match) FROM '$$PATH$$/3355.dat';

--
-- Data for Name: teammates; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.teammates (id, teammate_id, fk_teammates_player_match_stat, winrate_5_match, winrate_10_match, winrate_20_match, winrate_40_match) FROM stdin;
\.
COPY public.teammates (id, teammate_id, fk_teammates_player_match_stat, winrate_5_match, winrate_10_match, winrate_20_match, winrate_40_match) FROM '$$PATH$$/3359.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.users (id, user_id) FROM stdin;
\.
COPY public.users (id, user_id) FROM '$$PATH$$/3357.dat';

--
-- Data for Name: winrate_enemy; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.winrate_enemy (id, win, fk_winrate_enemy_player_match_stat) FROM stdin;
\.
COPY public.winrate_enemy (id, win, fk_winrate_enemy_player_match_stat) FROM '$$PATH$$/3365.dat';

--
-- Data for Name: winrate_teammate; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.winrate_teammate (id, win, fk_winrate_teammate_player_match_stat) FROM stdin;
\.
COPY public.winrate_teammate (id, win, fk_winrate_teammate_player_match_stat) FROM '$$PATH$$/3363.dat';

--
-- Name: enemies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.enemies_id_seq', 11079, true);


--
-- Name: player_match_stat_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.player_match_stat_id_seq', 11686, true);


--
-- Name: teammates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.teammates_id_seq', 8840, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.users_id_seq', 210, true);


--
-- Name: winrate_enemy_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.winrate_enemy_id_seq', 1, false);


--
-- Name: winrate_teammate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.winrate_teammate_id_seq', 1, false);


--
-- Name: enemies enemies_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.enemies
    ADD CONSTRAINT enemies_pkey PRIMARY KEY (id);


--
-- Name: player_match_stat player_match_stat_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.player_match_stat
    ADD CONSTRAINT player_match_stat_pkey PRIMARY KEY (id);


--
-- Name: teammates teammates_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.teammates
    ADD CONSTRAINT teammates_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: winrate_enemy winrate_enemy_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.winrate_enemy
    ADD CONSTRAINT winrate_enemy_pkey PRIMARY KEY (id);


--
-- Name: winrate_teammate winrate_teammate_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.winrate_teammate
    ADD CONSTRAINT winrate_teammate_pkey PRIMARY KEY (id);


--
-- Name: enemies enemies_fk_enemies_player_match_stat_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.enemies
    ADD CONSTRAINT enemies_fk_enemies_player_match_stat_fkey FOREIGN KEY (fk_enemies_player_match_stat) REFERENCES public.player_match_stat(id);


--
-- Name: player_match_stat player_match_stat_fk_player_match_stat_users_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.player_match_stat
    ADD CONSTRAINT player_match_stat_fk_player_match_stat_users_fkey FOREIGN KEY (fk_player_match_stat_users) REFERENCES public.users(id);


--
-- Name: teammates teammates_fk_teammates_player_match_stat_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.teammates
    ADD CONSTRAINT teammates_fk_teammates_player_match_stat_fkey FOREIGN KEY (fk_teammates_player_match_stat) REFERENCES public.player_match_stat(id);


--
-- Name: winrate_enemy winrate_enemy_fk_winrate_enemy_player_match_stat_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.winrate_enemy
    ADD CONSTRAINT winrate_enemy_fk_winrate_enemy_player_match_stat_fkey FOREIGN KEY (fk_winrate_enemy_player_match_stat) REFERENCES public.enemies(id);


--
-- Name: winrate_teammate winrate_teammate_fk_winrate_teammate_player_match_stat_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.winrate_teammate
    ADD CONSTRAINT winrate_teammate_fk_winrate_teammate_player_match_stat_fkey FOREIGN KEY (fk_winrate_teammate_player_match_stat) REFERENCES public.teammates(id);


--
-- PostgreSQL database dump complete
--

